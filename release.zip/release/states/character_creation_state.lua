CharacterCreationState = State:new()

function CharacterCreationState:init() end
function CharacterCreationState:enter() end
function CharacterCreationState:input() end
function CharacterCreationState:update(dt) end
function CharacterCreationState:render() end
function CharacterCreationState:exit() end


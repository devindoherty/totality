G_bug = {}

function G_bug:bugprint(name, bug)
    if DEBUG then
        print(name .. bug)
    end
end

